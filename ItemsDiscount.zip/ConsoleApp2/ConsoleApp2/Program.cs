﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace ConsoleApp2
{
    class Program
    {

        /*
         * Problem Statement:- Consider the following items in the shopping cart:

            Item	Qty	Price/Item
            Shirt	3	1000
            Trouser	4	2000
            Shoes	2	3000
            Ties	10	1000

            It should be possible for us to calculate and add coupon discounts to generate the final bill amount. Discount scenarios are as follows:
 
            1. Type-1:  Discount on all items. e.g: Flat 10% discount on all items
            2. Type-2: Discount on next item. e.g: If I add a coupon of 10% after trousers, only shoes will be discounted. 
            3. Type-3: Fixed discount on nth item in cart. e.g: Every 5th item will be free per item category.

         */

        static void Main(string[] args)
        {
            CartOperations cartOperations = new CartOperations();
            cartOperations.CalculateTypeOneDiscount(5);
            Console.WriteLine("------------------------- Type 1 --------------------------------------");
            Console.WriteLine(JsonConvert.SerializeObject(cartOperations.CartItems));
            cartOperations.CalculateTypeTwoDiscount();
            Console.WriteLine("------------------------- Type 2 --------------------------------------");
            Console.WriteLine(JsonConvert.SerializeObject(cartOperations.CartItems));
            cartOperations.CalculateTypeThreeDiscount(7);
            Console.WriteLine("------------------------- Type 3 --------------------------------------");
            Console.WriteLine(JsonConvert.SerializeObject(cartOperations.CartItems));
        }
    }

    public enum ItemGroup
    {
        Shirt,
        Trouser,
        Shoes,
        Ties
    }

    public class CartItem
    {
        public string ItemName { get; set; }
        public ItemGroup ItemGroup { get; set; }
        public int Quantity { get; set; }
        public long ItemPrice { get; set; }
        public long DiscountedPrice { get; set; }
        public long CouponDiscount { get; set; }
    }

    public class CartOperations : CartItem
    {
        public List<CartItem> CartItems { get; set; }
        public CartOperations()
        {
            CartItems = new List<CartItem>
{
                    new CartItem(){ItemName="white tshirt",ItemGroup=ItemGroup.Shirt,ItemPrice=1000,Quantity=3,DiscountedPrice=1000*3},
                    new CartItem(){ItemName="white Trouser",ItemGroup=ItemGroup.Trouser,ItemPrice=2000,Quantity=4,DiscountedPrice=2000*4,CouponDiscount=10},
                    new CartItem(){ItemName="white Shoes",ItemGroup=ItemGroup.Shoes,ItemPrice=3000,Quantity=2,DiscountedPrice=3000*2},
                    new CartItem(){ItemName="white Ties",ItemGroup=ItemGroup.Ties,ItemPrice=1000,Quantity=10,DiscountedPrice=1000*10}
 };
        }

        public void CalculateTypeOneDiscount(long discountPercent)
        {
            foreach (var item in CartItems)
            {
                var price = item.ItemPrice * item.Quantity;
                item.DiscountedPrice = price - ((price * discountPercent) / 100);
            }
        }
        public void CalculateTypeTwoDiscount()
        {
            for (int i = 0; i < CartItems.Count; i++)
            {
                var price = CartItems[i].ItemPrice * CartItems[i].Quantity;
                if (i > 0 && CartItems[i - 1].CouponDiscount > 0)
                {
                    CartItems[i].DiscountedPrice = price - ((price * CartItems[i - 1].CouponDiscount) / 100);
                }
                else
                {
                    CartItems[i].DiscountedPrice = price;
                }
            }
        }
        public void CalculateTypeThreeDiscount(int discountedNumber)
        {
            foreach (var item in CartItems)
            {
                int cnt = item.Quantity / discountedNumber;
                item.DiscountedPrice = (item.ItemPrice * (item.Quantity - cnt));
            }
        }
    }
}
